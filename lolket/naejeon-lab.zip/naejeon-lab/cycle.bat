@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run setup.bat first & pause & exit /b)
set PY=.venv\Scripts\python.exe
:ask
set LOOPS=
set /p LOOPS=몇 번 사이클을 돌까요? (숫자 입력, 그냥 Enter = 2): 
if "%LOOPS%"=="" set LOOPS=2
echo %LOOPS%| findstr /r "^[1-9][0-9]*$" >nul || (echo 1 이상의 숫자만 입력하세요. & goto ask)
echo.
echo 학습 사이클 %LOOPS%번 시작합니다.
%PY% -m lab cycle --trials 80 --loops %LOOPS%
pause
