@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (echo Run setup.bat first & pause & exit /b)
set PY=.venv\Scripts\python.exe
%PY% -m lab cycle --trials 80 --loops 2
pause
