"""학습 결과를 GitHub 저장소에 올림 → 룽잉닷컴이 raw URL로 읽음

방법 1) 로컬에 clone 해둔 저장소 폴더(github.repo_dir)에 복사 후 git commit/push  (권장, git 필요)
방법 2) GitHub API + 토큰(GITHUB_TOKEN)으로 파일 직접 업로드 (git 없어도 됨)
"""
import base64
import json
import os
import shutil
import subprocess
from pathlib import Path

import requests
from dotenv import dotenv_values

FILES = ["latest.json", "players.json", "pairs.json"]


def publish(cfg, log=print):
    gh = cfg.get("github", {})
    src = Path(cfg.get("output_dir", "output")) / "model"
    if not (src / "latest.json").exists():
        log("output/model/latest.json 이 없습니다. 먼저 train 을 실행하세요.")
        return False
    version = json.loads((src / "latest.json").read_text(encoding="utf-8"))["version"]
    sub = gh.get("path", "model")
    if gh.get("repo_dir"):
        repo = Path(gh["repo_dir"])
        dst = repo / sub
        dst.mkdir(parents=True, exist_ok=True)
        for f in FILES:
            if (src / f).exists():
                shutil.copy2(src / f, dst / f)
        def git(*a):
            return subprocess.run(["git", "-C", str(repo), *a], capture_output=True, text=True)
        git("add", sub)
        r = git("commit", "-m", f"model {version}")
        if "nothing to commit" in (r.stdout + r.stderr):
            log("변경 사항 없음 (이미 최신)")
            return True
        p = git("push")
        if p.returncode != 0:
            log("push 실패:\n" + p.stderr)
            return False
        log(f"GitHub 업로드 완료 (git): {sub}/ · {version}")
        return True

    vals = dotenv_values(".env") if os.path.exists(".env") else {}
    token = vals.get("GITHUB_TOKEN") or os.environ.get("GITHUB_TOKEN")
    repo = gh.get("repo")  # "owner/name"
    branch = gh.get("branch", "main")
    if not (token and repo):
        log("config.yaml 의 github.repo_dir 또는 (github.repo + .env GITHUB_TOKEN) 이 필요합니다.")
        return False
    # .env 에 따옴표·공백이 같이 들어간 경우 정리
    token = token.strip().strip('"').strip("'").strip()
    H = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}

    # 업로드 전에 토큰·저장소 권한부터 확인해서 원인을 알려줌
    me = requests.get("https://api.github.com/user", headers=H, timeout=30)
    if me.status_code == 401:
        log("❌ GitHub 토큰이 거부되었습니다 (401 Bad credentials).")
        log(f"   .env 의 GITHUB_TOKEN 값: {token[:8]}…{token[-4:]} (길이 {len(token)})")
        log("   - 토큰이 만료·삭제되었거나, 복사할 때 잘렸을 수 있습니다.")
        log("   - https://github.com/settings/tokens 에서 새 토큰을 만들어 .env 의 GITHUB_TOKEN= 뒤에 그대로 붙여넣으세요.")
        log(f"   - Fine-grained 토큰: Repository access 에 {repo} 선택 + Permissions → Contents: Read and write")
        log("   - Classic 토큰: repo 권한 체크")
        return False
    login = me.json().get("login") if me.status_code == 200 else None
    rp = requests.get(f"https://api.github.com/repos/{repo}", headers=H, timeout=30)
    if rp.status_code == 404:
        log(f"❌ 토큰({login})으로 저장소 {repo} 를 볼 수 없습니다.")
        log("   config.yaml 의 github.repo 이름을 확인하거나, 토큰의 Repository access 에 이 저장소를 추가하세요.")
        return False
    perms = (rp.json().get("permissions") or {}) if rp.status_code == 200 else {}
    if perms and not perms.get("push"):
        log(f"❌ 토큰({login})에 {repo} 쓰기 권한이 없습니다. 토큰 권한을 Contents: Read and write 로 바꿔주세요.")
        return False
    for f in FILES:
        if not (src / f).exists():
            continue
        url = f"https://api.github.com/repos/{repo}/contents/{sub}/{f}"
        cur = requests.get(url, headers=H, params={"ref": branch}, timeout=30)
        sha = cur.json().get("sha") if cur.status_code == 200 else None
        body = {"message": f"model {version}", "branch": branch,
                "content": base64.b64encode((src / f).read_bytes()).decode()}
        if sha:
            body["sha"] = sha
        r = requests.put(url, headers=H, json=body, timeout=60)
        if r.status_code not in (200, 201):
            log(f"{f} 업로드 실패: {r.status_code} {r.text[:200]}")
            if r.status_code in (403, 404):
                log("   → 토큰에 이 저장소의 Contents: Read and write 권한이 있는지 확인하세요.")
            return False
    log(f"GitHub 업로드 완료 (API): https://raw.githubusercontent.com/{repo}/{branch}/{sub}/latest.json")
    return True
